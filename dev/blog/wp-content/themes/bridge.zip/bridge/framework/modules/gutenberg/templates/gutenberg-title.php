<div class="qodef-gutenb-title-holder">
    <div class="qodef-gutenb-title-wrapper">
        <div class="qodef-gutenb-title-inner">
            <div class="qodef-grid">
                <?php if(!empty($title)) { ?>
                <<?php echo esc_attr($title_tag); ?> class="qodef-page-title entry-title"><?php echo esc_html($title); ?></<?php echo esc_attr($title_tag); ?>>
            <?php } ?>
            </div>
        </div>
    </div>
</div>