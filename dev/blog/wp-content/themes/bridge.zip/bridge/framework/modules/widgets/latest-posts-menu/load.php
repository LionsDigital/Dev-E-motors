<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/latest-posts-menu/latest-posts-menu.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/latest-posts-menu/functions.php';