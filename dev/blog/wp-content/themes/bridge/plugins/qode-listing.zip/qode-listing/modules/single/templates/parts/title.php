<div class="qode-ls-item-title">
	<h3 class="qode-ls-item-title-inner">
		<?php echo get_the_title(); ?>
	</h3>
</div>