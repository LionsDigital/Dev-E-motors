<div class="qode-split-scrolling-section">
    <?php echo do_shortcode($content); ?>
</div>