<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_product-list-masonry/product-list-masonry.php';
