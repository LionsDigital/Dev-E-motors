<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_image-with-text-over/image-with-text-over.php';
