<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_masonry-gallery/masonry-gallery.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_masonry-gallery/custom-styles/custom-styles.php';