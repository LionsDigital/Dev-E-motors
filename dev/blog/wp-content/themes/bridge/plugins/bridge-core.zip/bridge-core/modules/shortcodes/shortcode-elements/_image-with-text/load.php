<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_image-with-text/image-with-text.php';
