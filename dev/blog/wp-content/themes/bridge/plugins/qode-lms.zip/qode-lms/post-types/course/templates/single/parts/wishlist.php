<span class="qode-course-whishlist-wrapper">
	<a href="javascript:void(0)" class="qode-course-whishlist" data-course-id="<?php echo get_the_ID(); ?>">
        <i class="fa <?php echo esc_attr( $wishlist_icon ); ?>"></i>
        <span class="qode-course-wishlist-text">
            <?php echo esc_attr( $wishlist_text ); ?>
        </span>
    </a>
</span>
