<div class="qode-question-hint-holder">
    <span class="qode-hint-value">
        <?php echo esc_html( $hint_value ); ?>
    </span>
</div>